### How to use

#1. modify `.env` and start (`docker-compose up -d`)
#2. setup Grafana (add datasource)
